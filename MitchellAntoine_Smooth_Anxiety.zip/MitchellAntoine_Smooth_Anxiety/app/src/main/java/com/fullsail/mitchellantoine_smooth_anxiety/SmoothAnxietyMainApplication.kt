package com.fullsail.mitchellantoine_smooth_anxiety

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SmoothAnxietyMainApplication : Application()

const val TAG = "Measuring Data Sample"
